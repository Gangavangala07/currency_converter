from flask import Flask, render_template, request
import requests

app = Flask(__name__)

def get_currency_symbols():
    try:
        # This API gives a base USD rate table with all currencies
        url = "https://open.er-api.com/v6/latest/USD"
        response = requests.get(url, timeout=5)
        data = response.json()
        if data["result"] == "success":
            return sorted(data["rates"].keys())
        else:
            print("Failed to get currency symbols:", data)
    except Exception as e:
        print("Error fetching currency symbols:", e)

    # fallback
    print("Using fallback currency list.")
    return ['USD', 'INR', 'EUR', 'GBP', 'AUD', 'CAD', 'JPY', 'CNY']

def convert_currency(amount, from_currency, to_currency):
    try:
        url = f"https://open.er-api.com/v6/latest/{from_currency}"
        response = requests.get(url, timeout=5)
        data = response.json()

        if data["result"] == "success":
            rates = data["rates"]
            if to_currency in rates:
                converted_amount = amount * rates[to_currency]
                return converted_amount
            else:
                print(f"Currency {to_currency} not found in rates.")
        else:
            print("Conversion API failed:", data)
    except Exception as e:
        print("Exception during conversion:", e)

    return None

@app.route('/', methods=['GET', 'POST'])
def index():
    currencies = get_currency_symbols()
    result = None

    if request.method == 'POST':
        amount = request.form.get('amount', type=float)
        from_curr = request.form.get('from_currency')
        to_curr = request.form.get('to_currency')

        if not all([amount, from_curr, to_curr]):
            result = "Please enter a valid amount and select currencies."
        else:
            converted = convert_currency(amount, from_curr, to_curr)
            if converted is not None:
                result = f"{amount:.2f} {from_curr} = {converted:.2f} {to_curr}"
            else:
                result = "Conversion failed. Please try again."

    return render_template("index.html", currencies=currencies, result=result)

if __name__ == '__main__':
    app.run(debug=True)
